package com.glassicons
import org.junit.Assert.assertEquals
import org.junit.Test
class SafeNameTest { @Test fun keepsPackageNames() { assertEquals("com.whatsapp", safeName("com.whatsapp")); assertEquals("a_b", safeName("a/b")) } }
