package com.glassicons

import android.app.Application
import android.content.Intent
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    private val repo = AppRepo(app)
    val store = IconStore(app)
    private val prefs = app.getSharedPreferences("settings", 0)

    val apps = MutableStateFlow<List<AppItem>>(emptyList())
    val query = MutableStateFlow("")
    val progress = MutableStateFlow<Pair<Int, Int>?>(null)
    val rev = MutableStateFlow(0)
    val message = MutableStateFlow<String?>(null)
    val settings = MutableStateFlow(
        GlassSettings(
            prefs.getInt("alpha", 150), prefs.getFloat("shadow", 0.5f), prefs.getFloat("scale", 0.6f),
            prefs.getBoolean("dark", false), prefs.getBoolean("fg", false)
        )
    )
    val visible = combine(apps, query) { a, q ->
        if (q.isBlank()) a else a.filter { it.label.contains(q, true) || it.pkg.contains(q, true) }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init { refresh() }

    fun refresh() = viewModelScope.launch(Dispatchers.IO) {
        try { apps.value = repo.scan(); rev.value++ } catch (e: Exception) { message.value = "Scan failed: ${e.message}" }
    }

    fun updateSettings(s: GlassSettings) {
        settings.value = s
        prefs.edit().putInt("alpha", s.alpha).putFloat("shadow", s.shadow).putFloat("scale", s.scale)
            .putBoolean("dark", s.dark).putBoolean("fg", s.fgOnly).apply()
    }

    fun original(a: AppItem) = repo.icon(a)
    private fun generate(a: AppItem) = store.save(a.pkg, GlassEngine.render(repo.icon(a), settings.value))

    fun generateAll(onlyStale: Boolean) {
        if (progress.value != null) return
        viewModelScope.launch(Dispatchers.Default) {
            val list = apps.value.filter { !onlyStale || store.isStale(it) }
            var failed = 0
            list.forEachIndexed { i, a ->
                progress.value = (i + 1) to list.size
                try { generate(a) } catch (e: Exception) { failed++ }
            }
            progress.value = null; rev.value++
            message.value = "Generated ${list.size - failed} icons" + if (failed > 0) ", $failed failed" else ""
        }
    }

    fun regenerate(a: AppItem) = viewModelScope.launch(Dispatchers.Default) {
        try { generate(a); rev.value++ } catch (e: Exception) { message.value = "Failed: ${e.message}" }
    }

    /** Practical launcher alternative: pinned home-screen shortcut using the glass icon. */
    fun pin(a: AppItem) {
        val intent = app.packageManager.getLaunchIntentForPackage(a.pkg)?.apply { action = Intent.ACTION_MAIN }
        val bmp = store.file(a.pkg).takeIf { it.exists() }?.let { android.graphics.BitmapFactory.decodeFile(it.path) }
        if (intent == null || bmp == null) { message.value = "Generate the icon first"; return }
        val info = ShortcutInfoCompat.Builder(app, "glass_${a.pkg}").setShortLabel(a.label)
            .setIcon(IconCompat.createWithBitmap(bmp)).setIntent(intent).build()
        message.value = if (ShortcutManagerCompat.requestPinShortcut(app, info, null)) "Confirm the shortcut on your home screen" else "Launcher doesn't support pinning"
    }
}
