package com.glassicons

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import java.io.File
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class AppItem(val label: String, val pkg: String, val activity: String, val updated: Long)
data class GlassSettings(val alpha: Int = 150, val shadow: Float = 0.5f, val scale: Float = 0.6f, val dark: Boolean = false, val fgOnly: Boolean = false)

fun safeName(s: String) = s.replace(Regex("[^A-Za-z0-9._-]"), "_")

class AppRepo(private val ctx: Context) {
    private val pm get() = ctx.packageManager

    @Suppress("DEPRECATION")
    fun scan(): List<AppItem> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val res = if (android.os.Build.VERSION.SDK_INT >= 33)
            pm.queryIntentActivities(i, PackageManager.ResolveInfoFlags.of(0))
        else pm.queryIntentActivities(i, 0)
        return res.mapNotNull { r ->
            val a = r.activityInfo ?: return@mapNotNull null
            val updated = try { pm.getPackageInfo(a.packageName, 0).lastUpdateTime } catch (e: Exception) { 0L }
            AppItem(r.loadLabel(pm).toString(), a.packageName, a.name, updated)
        }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
    }

    fun icon(a: AppItem): Drawable = pm.getActivityIcon(ComponentName(a.pkg, a.activity))
}

class IconStore(ctx: Context) {
    private val dir = File(ctx.filesDir, "icons").apply { mkdirs() }
    fun file(pkg: String) = File(dir, safeName(pkg) + ".png")
    fun save(pkg: String, b: Bitmap) { file(pkg).outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) } }
    /** Missing, or older than the app's last update (original icon may have changed). */
    fun isStale(a: AppItem): Boolean { val f = file(a.pkg); return !f.exists() || f.lastModified() < a.updated }
    fun zipTo(out: OutputStream): Int {
        var n = 0
        ZipOutputStream(out).use { z ->
            dir.listFiles()?.filter { it.extension == "png" }?.forEach { f ->
                z.putNextEntry(ZipEntry(f.name)); f.inputStream().use { it.copyTo(z) }; z.closeEntry(); n++
            }
        }
        return n
    }
}
