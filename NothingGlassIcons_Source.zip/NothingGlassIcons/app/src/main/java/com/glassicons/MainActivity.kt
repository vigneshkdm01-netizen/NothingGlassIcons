package com.glassicons

import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark = isSystemInDarkTheme()
            val ctx = LocalContext.current
            val scheme = if (Build.VERSION.SDK_INT >= 31) { if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx) }
            else if (dark) darkColorScheme() else lightColorScheme()
            MaterialTheme(colorScheme = scheme) { Surface(Modifier.fillMaxSize()) { Screen() } }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Screen(vm: MainViewModel = viewModel()) {
    val ctx = LocalContext.current
    val visible by vm.visible.collectAsStateWithLifecycle()
    val all by vm.apps.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val rev by vm.rev.collectAsStateWithLifecycle()
    val msg by vm.message.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val host = remember { SnackbarHostState() }
    var showSettings by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(msg) { msg?.let { host.showSnackbar(it); vm.message.value = null } }

    val pngLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        val p = pending
        if (uri != null && p != null) runCatching {
            ctx.contentResolver.openOutputStream(uri)!!.use { o -> vm.store.file(p).inputStream().use { it.copyTo(o) } }
        }.onSuccess { vm.message.value = "PNG saved" }.onFailure { vm.message.value = "Export failed: ${it.message}" }
    }
    val zipLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) runCatching {
            ctx.contentResolver.openOutputStream(uri)!!.use { vm.store.zipTo(it) }
        }.onSuccess { vm.message.value = "ZIP saved ($it icons)" }.onFailure { vm.message.value = "Export failed: ${it.message}" }
    }

    val generated = remember(rev, all) { all.count { !vm.store.file(it.pkg).let { f -> !f.exists() } } }

    Scaffold(
        snackbarHost = { SnackbarHost(host) },
        topBar = {
            TopAppBar(title = { Text("Nothing Glass Icons") }, actions = {
                IconButton(onClick = { vm.refresh() }) { Icon(Icons.Default.Refresh, "Refresh apps") }
                IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Settings") }
                IconButton(onClick = { showInfo = true }) { Icon(Icons.Default.Info, "About") }
            })
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 16.dp)) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("$generated / ${all.size} icons generated", style = MaterialTheme.typography.titleMedium)
                    progress?.let { (d, t) ->
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(progress = { d / t.toFloat() }, modifier = Modifier.fillMaxWidth())
                        Text("$d / $t", style = MaterialTheme.typography.bodySmall)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { vm.generateAll(false) }, enabled = progress == null) { Text("Generate all") }
                        OutlinedButton(onClick = { vm.generateAll(true) }, enabled = progress == null) { Text("New/updated") }
                    }
                    TextButton(onClick = { zipLauncher.launch("NothingGlassIcons.zip") }) { Text("Export all as ZIP") }
                }
            }
            OutlinedTextField(query, { vm.query.value = it }, Modifier.fillMaxWidth().padding(vertical = 8.dp),
                label = { Text("Search apps") }, singleLine = true)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(visible, key = { it.pkg }) { a ->
                    val orig = remember(a.pkg) { runCatching { vm.original(a).toBitmap(128, 128) }.getOrNull() }
                    val glass = remember(a.pkg, rev) {
                        vm.store.file(a.pkg).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path, BitmapFactory.Options().apply { inSampleSize = 2 }) }
                    }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                orig?.let { Image(it.asImageBitmap(), "Original", Modifier.size(56.dp)) }
                                Spacer(Modifier.width(12.dp))
                                Box(Modifier.size(64.dp).background(Brush.linearGradient(listOf(Color(0xFF7A8CA5), Color(0xFFC9A0A0))), RoundedCornerShape(16.dp)),
                                    contentAlignment = Alignment.Center) {
                                    glass?.let { Image(it.asImageBitmap(), "Glass", Modifier.size(60.dp)) }
                                }
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text(a.label, style = MaterialTheme.typography.titleSmall)
                                    Text(a.pkg, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            Row {
                                TextButton(onClick = { vm.regenerate(a) }) { Text("Regenerate") }
                                TextButton(enabled = glass != null, onClick = { pending = a.pkg; pngLauncher.launch(safeName(a.pkg) + ".png") }) { Text("PNG") }
                                TextButton(enabled = glass != null, onClick = { vm.pin(a) }) { Text("Pin") }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSettings) AlertDialog(onDismissRequest = { showSettings = false }, confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Done") } },
        title = { Text("Generation settings") }, text = {
            Column {
                Text("Glass opacity"); Slider(settings.alpha / 255f, { vm.updateSettings(settings.copy(alpha = (it * 255).toInt())) })
                Text("Shadow"); Slider(settings.shadow, { vm.updateSettings(settings.copy(shadow = it)) })
                Text("Logo size"); Slider(settings.scale, { vm.updateSettings(settings.copy(scale = it)) }, valueRange = 0.4f..0.8f)
                Row(verticalAlignment = Alignment.CenterVertically) { Switch(settings.dark, { vm.updateSettings(settings.copy(dark = it)) }); Spacer(Modifier.width(8.dp)); Text("Dark glass") }
                Row(verticalAlignment = Alignment.CenterVertically) { Switch(settings.fgOnly, { vm.updateSettings(settings.copy(fgOnly = it)) }); Spacer(Modifier.width(8.dp)); Text("Logo foreground only") }
                Text("Tap Generate all to apply changes.", style = MaterialTheme.typography.bodySmall)
            }
        })
    if (showInfo) AlertDialog(onDismissRequest = { showInfo = false }, confirmButton = { TextButton(onClick = { showInfo = false }) { Text("OK") } },
        title = { Text("About") }, text = {
            Text("Generates frosted glass icons from each installed app's ORIGINAL icon, for every launchable app. " +
                "Android doesn't let an app push icons into Nothing Launcher. Exported PNGs do NOT change your home screen by themselves. " +
                "Use Pin to add a home-screen shortcut with the glass icon, or use the PNGs with an icon-pack builder.")
        })
}
