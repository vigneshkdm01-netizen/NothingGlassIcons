package com.glassicons

import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable

/** Applies the frosted translucent Nothing-style glass look around the ORIGINAL app logo (never redrawn). */
object GlassEngine {
    fun render(src: Drawable, s: GlassSettings, size: Int = 512): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val f = size.toFloat()
        val cx = f / 2f
        val rad = f * 0.44f
        fun paint() = Paint(Paint.ANTI_ALIAS_FLAG)

        // soft shadow
        c.drawCircle(cx, cx + f * 0.015f, rad, paint().apply {
            color = Color.argb((100 * s.shadow).toInt().coerceIn(0, 255), 0, 0, 0)
            maskFilter = BlurMaskFilter(f * 0.035f, BlurMaskFilter.Blur.NORMAL)
        })
        // milky translucent body (lower opacity in dark mode)
        val a = (if (s.dark) s.alpha * 0.4f else s.alpha.toFloat()).toInt().coerceIn(0, 255)
        c.drawCircle(cx, cx, rad, paint().apply { color = Color.argb(a, 255, 255, 255) })
        // faint top-down light falloff for glass depth
        c.drawCircle(cx, cx, rad, paint().apply {
            shader = LinearGradient(0f, cx - rad, 0f, cx + rad, Color.argb(70, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        })
        // thin glass rim
        c.drawCircle(cx, cx, rad - f * 0.004f, paint().apply {
            style = Paint.Style.STROKE; strokeWidth = f * 0.008f; color = Color.argb(110, 255, 255, 255)
        })

        // original logo in the centre
        val d = rad * 2f * s.scale
        val adaptive = src is AdaptiveIconDrawable
        val layer: Drawable = if (src is AdaptiveIconDrawable && s.fgOnly) src.foreground else src
        val box = if (adaptive) d * 108f / 72f else d
        layer.setBounds((cx - box / 2).toInt(), (cx - box / 2).toInt(), (cx + box / 2).toInt(), (cx + box / 2).toInt())
        c.save()
        if (adaptive && !s.fgOnly) c.clipPath(Path().apply { addCircle(cx, cx, d / 2f, Path.Direction.CW) })
        layer.draw(c)
        c.restore()
        return out
    }
}
